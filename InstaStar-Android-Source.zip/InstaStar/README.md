# InstaStar Android starter

A native Android social-feed prototype built with Kotlin and Jetpack Compose.

## Included
- Dark premium gradient-inspired UI
- Home feed with sample posts
- Story strip
- Local like and save interactions
- Bottom navigation: Home, Explore, Create, Activity, Profile

## Requirements
- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35
- Internet connection for Gradle dependency resolution

## Build the APK
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

Or from a terminal with Android SDK configured:
```bash
./gradlew assembleDebug
```

## Current prototype limitations
This is a UI prototype. It does not yet have real user accounts, server-side posts,
photo/video uploads, chat delivery, push notifications, or moderation. The sample
posts and likes are local demo data and reset when the app restarts.

## Next production steps
- Add Firebase Authentication for sign-up/login.
- Add Cloud Firestore for profiles, follows, posts, comments and likes.
- Add Firebase Storage for media.
- Add Firebase Cloud Messaging for notifications.
- Add server-side security rules, reporting, blocking and content moderation.
- Configure app signing before publishing.
