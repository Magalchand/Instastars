package com.instastar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF0D0B18)
private val Panel = Color(0xFF1B172B)
private val Purple = Color(0xFF9B5CFF)
private val Pink = Color(0xFFFF5DA2)
private val Ink = Color(0xFFF8F4FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InstaStarApp() }
    }
}

private data class Post(
    val user: String,
    val handle: String,
    val caption: String,
    val art: String,
    val likes: Int
)

@Composable
fun InstaStarApp() {
    var tab by remember { mutableIntStateOf(0) }
    val posts = remember {
        listOf(
            Post("Aarav Mehta", "@aarav", "Chasing sunsets and good vibes ✨", "🌅", 248),
            Post("Mira Kapoor", "@mira.k", "Little moments, big memories 💜", "🏞️", 126),
            Post("Kabir Singh", "@kabir", "Weekend mode: ON 🚀", "🌌", 89)
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Purple
    )) {
        Scaffold(
            containerColor = Night,
            topBar = { TopBar() },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Ink) {
                    val labels = listOf("Home", "Explore", "Create", "Activity", "Profile")
                    val icons = listOf("⌂", "⌕", "＋", "♡", "☺")
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Text(icons[index], fontSize = 23.sp) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Pink,
                                selectedTextColor = Pink,
                                indicatorColor = Color(0xFF34234D),
                                unselectedIconColor = Ink.copy(alpha = .72f),
                                unselectedTextColor = Ink.copy(alpha = .72f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(posts, Modifier.padding(padding))
                1 -> SimpleScreen("Explore", "Discover photos, creators and trends.", Modifier.padding(padding))
                2 -> CreateScreen(Modifier.padding(padding))
                3 -> SimpleScreen("Activity", "Your likes, comments and new followers will appear here.", Modifier.padding(padding))
                else -> ProfileScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        Modifier.fillMaxWidth().background(Night).padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("InstaStar", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold,
            color = Ink)
        Text("✉", fontSize = 25.sp, color = Ink)
    }
}

@Composable
private fun HomeScreen(posts: List<Post>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { Stories() }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text("For you", color = Ink, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("Following  ·  ", color = Purple, fontSize = 13.sp)
            }
        }
        items(posts) { post -> PostCard(post) }
    }
}

@Composable
private fun Stories() {
    Column(Modifier.padding(top = 4.dp)) {
        Text("  Stories", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(15.dp)
        ) {
            listOf("Your story" to "＋", "Aarav" to "🧑🏻", "Mira" to "👩🏻", "Kabir" to "🧔🏻", "Zoya" to "👩🏽").forEachIndexed { i, pair ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(62.dp).background(
                            Brush.linearGradient(listOf(Purple, Pink)), CircleShape
                        ).padding(3.dp).background(Panel, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(pair.second, fontSize = if (i == 0) 27.sp else 25.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(pair.first, color = Ink.copy(alpha = .85f), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun PostCard(post: Post) {
    var liked by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var commentsOpen by remember { mutableStateOf(false) }

    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).background(
                    Brush.linearGradient(listOf(Purple, Pink)), CircleShape
                ), contentAlignment = Alignment.Center) {
                    Text(post.user.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(post.user, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(post.handle, color = Ink.copy(alpha = .55f), fontSize = 11.sp)
                }
                Text("•••", color = Ink, fontSize = 20.sp)
            }
            Box(
                Modifier.fillMaxWidth().height(265.dp).background(
                    Brush.linearGradient(listOf(Color(0xFF39215E), Color(0xFF172A48), Color(0xFF7B3E77)))
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(post.art, fontSize = 76.sp)
                Text("INSTASTAR", Modifier.align(Alignment.BottomEnd).padding(12.dp),
                    color = Color.White.copy(alpha = .55f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (liked) "♥" else "♡", color = if (liked) Pink else Ink,
                    fontSize = 28.sp, modifier = Modifier.clickable { liked = !liked })
                Spacer(Modifier.width(15.dp))
                Text("◯", color = Ink, fontSize = 24.sp,
                    modifier = Modifier.clickable { commentsOpen = !commentsOpen })
                Spacer(Modifier.width(15.dp))
                Text("↗", color = Ink, fontSize = 24.sp)
                Spacer(Modifier.weight(1f))
                Text(if (saved) "▣" else "♧", color = if (saved) Purple else Ink,
                    fontSize = 23.sp, modifier = Modifier.clickable { saved = !saved })
            }
            Text("${post.likes + if (liked) 1 else 0} likes", color = Ink,
                fontWeight = FontWeight.Bold, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 14.dp))
            Text(post.caption, color = Ink.copy(alpha = .9f), fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp))
            if (commentsOpen) {
                Text("Comments will be available when accounts and backend are connected.",
                    color = Purple, fontSize = 11.sp,
                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp))
            } else {
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun CreateScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("＋", color = Purple, fontSize = 58.sp)
        Text("Create a post", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Photo and video uploads will be connected in the next backend step.",
            color = Ink.copy(alpha = .65f), fontSize = 13.sp)
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(90.dp).background(Brush.linearGradient(listOf(Purple, Pink)), CircleShape),
            contentAlignment = Alignment.Center) { Text("⭐", fontSize = 38.sp) }
        Spacer(Modifier.height(12.dp))
        Text("Your InstaStar profile", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("@your_username", color = Purple)
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("0", "Posts"); Stat("0", "Followers"); Stat("0", "Following")
        }
        Spacer(Modifier.height(22.dp))
        Text("Your bio will appear here.", color = Ink.copy(alpha = .65f))
    }
}

@Composable
private fun Stat(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(number, color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Ink.copy(alpha = .65f), fontSize = 12.sp)
    }
}

@Composable
private fun SimpleScreen(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Ink.copy(alpha = .65f))
    }
}
